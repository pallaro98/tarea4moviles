package iteso.mx.itesogram

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}
